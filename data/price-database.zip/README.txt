Basis data harga AHSP · 21 November 2026

Sumber harga tidak sama dengan harga siap pakai. Tabel source_prices menyimpan kutipan/calon harga; tabel prices hanya pasangan sumber daya/wilayah yang dipilih untuk pengisian otomatis. Semua identitas AHSP tercatat dalam resources, termasuk yang belum memiliki harga.

Buka price-database.sqlite menggunakan SQLite atau DB Browser for SQLite.
Contoh query:
SELECT * FROM ahs_price_lookup WHERE region='Lampung' AND sub_region='Lampung';
SELECT * FROM unpriced_resources;
SELECT * FROM source_prices WHERE source_name LIKE '%Semen%';

Prioritas: bahan/sewa dari jurnal yang kompatibel; upah dari peraturan daerah yang tersedia. Satuan/spec/wilayah berbeda tidak disamakan. Eskalasi, konversi, asumsi dan pajak tersimpan dalam evidence_json/escalation_json/remarks. Harga sebelum 2026 yang belum memiliki indeks sebanding tetap belum siap pakai. Tarif 2026 belum berarti survei resmi2026; lihat price_kind dan rujukannya.

Harga dengan PPN tidak dinyatakan tetap diberi keterangan, bukan diklaim sebagai harga bersih. Acuan provinsi dibedakan dari harga lokal. Persetujuan pengguna21 November2026 membolehkan acuan bahan/alat wilayah terdekat dalam provinsi sama dengan label estimasi; bukan upah. Kolom prices.regional_reference_json menyimpan lokasi sumber dan target. Ongkos angkut serta kondisi pasar target perlu ditinjau sebelum anggaran final. Acuan Lampung menggunakan Bandar Lampung sesuai instruksi pengguna, 8jam/OH; upah bulanan/30hari. Tidak ada TKDN numerik yang dikarang.
